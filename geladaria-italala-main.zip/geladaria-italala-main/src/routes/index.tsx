import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Geladaria Italala | Sua escolha, seu sabor" },
      {
        name: "description",
        content:
          "Descubra os sabores, produtos, sobremesas e encomendas da Geladaria Italala em Luanda.",
      },
      { property: "og:title", content: "Geladaria Italala | Sua escolha, seu sabor" },
      {
        property: "og:description",
        content:
          "Descubra os sabores, produtos, sobremesas e encomendas da Geladaria Italala em Luanda.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="min-h-svh w-full overflow-hidden">
      <iframe
        className="italala-frame block min-h-svh w-full border-0"
        src="/geladaria-italala.html"
        title="Geladaria Italala — sua escolha, seu sabor"
      />
    </main>
  );
}