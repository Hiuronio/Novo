# Geladaria Italala

Não altera nada, apenas melhore e deixa mais animado.

Deixa todas as fotos, imagens, funções e informações.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://geladaria-italala.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/dc4a094f-247f-4666-a3d1-ef846cd6120a).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
